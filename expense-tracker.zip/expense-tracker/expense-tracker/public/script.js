// DOM element references
const form = document.getElementById('expense-form');
const expenseList = document.getElementById('expense-list');
const totalExpensesElem = document.getElementById('total-expenses');
const filterCategory = document.getElementById('filter-category');

// Local storage for expenses
let expenses = [];

// Function to render expenses in the UI
function renderExpenses(filteredExpenses = expenses) {
    expenseList.innerHTML = ''; // Clear current list
    let total = 0;

    filteredExpenses.forEach((expense) => {
        const { _id, title, amount, date, category } = expense;

        // Ensure data is complete before rendering
        if (!title || isNaN(amount) || !date || !category) return;

        // Add to total amount
        total += parseFloat(amount);

        // Create list item for each expense
        const li = document.createElement('li');
        li.innerHTML = `
            ${date} - ${title} (${category}): $${amount.toFixed(2)} 
            <button onclick="deleteExpense('${_id}')">Delete</button>
        `;
        expenseList.appendChild(li);
    });

    // Update the total displayed
    totalExpensesElem.textContent = total.toFixed(2);
}

// Function to fetch all expenses from the backend
async function fetchExpenses() {
    try {
        const response = await fetch('/expenses'); // Make a GET request to the backend
        if (response.ok) {
            expenses = await response.json(); // Parse the response JSON
            renderExpenses(); // Render the fetched expenses
        } else {
            throw new Error('Failed to fetch expenses from the server.');
        }
    } catch (error) {
        console.error(error.message); // Log the error for debugging
        alert('An error occurred while fetching expenses.');
    }
}

// Function to add a new expense
form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = document.getElementById('title').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const date = document.getElementById('date').value;
    const category = document.getElementById('category').value;

    // Validate input
    if (!title || isNaN(amount) || !date || !category) {
        alert('Please fill in all fields correctly!');
        return;
    }

    const expense = { title, amount, date, category };

    try {
        const response = await fetch('/add-expense', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(expense),
        });

        if (response.ok) {
            const savedExpense = await response.json();
            expenses.push(savedExpense); // Add to local list
            renderExpenses(); // Refresh UI
            form.reset(); // Clear the form
        } else {
            const errorData = await response.json();
            alert(errorData.error || 'Failed to save the expense.');
        }
    } catch (error) {
        console.error(error.message);
        alert('An unexpected error occurred while adding the expense.');
    }
});

// Function to delete an expense
async function deleteExpense(id) {
    try {
        const response = await fetch(`/delete-expense/${id}`, { method: 'DELETE' });

        if (response.ok) {
            // Remove expense locally
            expenses = expenses.filter((expense) => expense._id !== id);
            renderExpenses(); // Refresh UI
        } else {
            const errorData = await response.json();
            alert(errorData.error || 'Failed to delete the expense.');
        }
    } catch (error) {
        console.error(error.message);
        alert('An unexpected error occurred while deleting the expense.');
    }
}

// Function to filter expenses by category
filterCategory.addEventListener('change', () => {
    const category = filterCategory.value;

    if (category) {
        // Filter based on selected category
        const filteredExpenses = expenses.filter((expense) => expense.category === category);
        renderExpenses(filteredExpenses);
    } else {
        // If "All" is selected, show all expenses
        renderExpenses();
    }
});

// Initial fetch of expenses on page load
fetchExpenses();
