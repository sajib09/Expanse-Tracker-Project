const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/expense-tracker', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Define the Expense schema and model
const ExpenseSchema = new mongoose.Schema({
    title: String,
    amount: Number,
    date: String,
    category: String,
});

const Expense = mongoose.model('Expense', ExpenseSchema);

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// POST route to add a new expense
app.post('/add-expense', async (req, res) => {
    const { title, amount, date, category } = req.body;

    if (!title || !amount || !date || !category) {
        return res.status(400).json({ error: 'All fields are required!' });
    }

    try {
        const expense = new Expense({ title, amount, date, category });
        const savedExpense = await expense.save();
        res.status(201).json(savedExpense);
    } catch (error) {
        res.status(500).json({ error: 'Failed to save expense.' });
    }
});

app.get('/expenses', async (req, res) => {
    try {
        const expenses = await Expense.find(); // Fetch all expenses from MongoDB
        res.status(200).json(expenses); // Send them as JSON
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch expenses.' });
    }
});


// DELETE route to delete an expense by ID
app.delete('/delete-expense/:id', async (req, res) => {
    const { id } = req.params;

    try {
        await Expense.findByIdAndDelete(id);
        res.status(200).json({ message: 'Expense deleted successfully!' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete expense.' });
    }
});

// Fallback for serving frontend
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
